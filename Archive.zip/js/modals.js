// js/modals.js — final working version (async include-safe)
(function () {
  /**
   * Safely waits until includes are fully loaded
   * and overlay-root has modal panels available
   */
  function whenIncludesReady(callback) {
    if (window.__includesReady) return callback();

    document.addEventListener("includesLoaded", () => {
      window.__includesReady = true;
      callback();
    });

    // Fallback safety timer (in case event missed)
    setTimeout(() => {
      if (!window.__includesReady) {
        console.warn("[modals] Fallback triggered (includesLoaded not fired)");
        window.__includesReady = true;
        callback();
      }
    }, 3000);
  }

  whenIncludesReady(() => {
    const overlay = document.getElementById("overlay-root");
    if (!overlay) {
      console.error("[modals] overlay-root not found");
      return;
    }

    /* ---------- Overlay helpers ---------- */
    function showOverlay() {
      overlay.classList.add("open");
      requestAnimationFrame(() => overlay.classList.add("visible"));
      document.body.style.overflow = "hidden";
    }

    function hideOverlay() {
      overlay.classList.remove("visible");
      overlay.querySelectorAll(".modal-panel.open").forEach(p => p.classList.remove("open"));
      setTimeout(() => {
        overlay.classList.remove("open");
        document.body.style.overflow = "";
      }, 250);
    }

    /* ---------- OPEN: handle data-open-modal triggers ---------- */
    document.addEventListener("click", (e) => {
      const trigger = e.target.closest("[data-open-modal]");
      if (!trigger) return;

      e.preventDefault();
      const name = trigger.getAttribute("data-open-modal");
      const modalId = `${name}-modal`;
      const panel = overlay.querySelector(`#${CSS.escape(modalId)}`);

      if (panel) {
        showOverlay();
        panel.classList.add("open");
      } else {
        console.warn(`[modals] Panel not found: #${modalId}`);
      }
    });

    /* ---------- CLOSE: button, backdrop, escape ---------- */
    document.addEventListener("click", (e) => {
      if (e.target.matches(".modal-close")) {
        e.preventDefault();
        hideOverlay();
      }
    });

    overlay.addEventListener("click", (e) => {
      if (e.target === overlay) hideOverlay();
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape" && overlay.classList.contains("visible")) {
        hideOverlay();
      }
    });

    /* ---------- COOKIE: Read More opens cookies modal ---------- */
    document.addEventListener("click", (e) => {
      const link = e.target.closest("#cookie-readmore");
      if (!link) return;

      e.preventDefault();
      const popup = document.getElementById("cookie-popup");
      if (popup) popup.classList.remove("show");

      const cookiesPanel = overlay.querySelector("#cookies-modal");
      if (cookiesPanel) {
        showOverlay();
        cookiesPanel.classList.add("open");
      }
    });

    console.info("[modals] ✅ Ready (includes loaded & listeners attached)");
  });
})();
