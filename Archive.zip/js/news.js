document.addEventListener("DOMContentLoaded", () => {
  // --- Safety reset on load ---
  const modal = document.getElementById("newsModal");
  const image = document.getElementById("newsModalImage");
  const title = document.getElementById("newsModalTitle");
  const date = document.getElementById("newsModalDate");
  const content = document.getElementById("newsModalContent");
  const closeBtn = document.getElementById("newsModalClose");

  if (modal) {
    modal.style.display = "none";
    modal.classList.remove("show", "visible");
  }

  // --- Load news items from JSON ---
  fetch("includes/news.json")
    .then(res => res.json())
    .then(news => {
      const container = document.getElementById("news-container");
      const today = new Date();

      container.innerHTML = news.map(item => {
        const dateObj = new Date(item.date);
        const daysOld = (today - dateObj) / (1000 * 60 * 60 * 24);
        const isNew = daysOld <= 30;

        return `
          <div class="news-card" 
               data-title="${item.title}" 
               data-date="${item.date}" 
               data-content="${item.content}" 
               data-image="${item.image || ''}">
            <div class="icon">${item.icon}</div>
            ${isNew ? `<span class="new-badge">NEW</span>` : ""}
            ${item.image ? `<img src="${item.image}" alt="${item.title}" class="news-thumb">` : ""}
            <div class="date">${dateObj.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' })}</div>
            <h3>${item.title}</h3>
            <p>${item.content.split('\n')[0]}</p>
            <span class="read-more">Read More →</span>
          </div>
        `;
      }).join("");

      // --- Modal open/close functions ---
      function openNewsModal(card) {
        const article = {
          title: card.dataset.title,
          date: card.dataset.date,
          content: card.dataset.content,
          image: card.dataset.image
        };

        title.textContent = article.title;
        date.textContent = new Date(article.date).toLocaleDateString("en-GB", {
          day: "2-digit",
          month: "long",
          year: "numeric"
        });

        // Handle image
        if (article.image) {
          image.src = article.image;
          image.style.display = "block";
        } else {
          image.style.display = "none";
        }

        // Basic markdown formatting
        const formatted = article.content
          .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
          .replace(/\*(.*?)\*/g, "<em>$1</em>")
          .replace(/\n/g, "<br>");
        content.innerHTML = formatted;

        // Show modal
        modal.style.display = "flex";
        modal.classList.add("show");
        document.body.style.overflow = "hidden";
        setTimeout(() => modal.classList.add("visible"), 10);
      }

      function closeNewsModal() {
        modal.classList.remove("visible");
        setTimeout(() => {
          modal.classList.remove("show");
          modal.style.display = "none";
          document.body.style.overflow = "auto";
        }, 300);
      }

      // --- Event bindings ---
      document.querySelectorAll(".news-card").forEach(card => {
        card.addEventListener("click", e => {
          const target = e.target;
          if (!target.classList.contains("read-more") && !target.closest(".read-more")) {
            openNewsModal(card);
          }
        });

        const readMore = card.querySelector(".read-more");
        if (readMore) {
          readMore.addEventListener("click", e => {
            e.preventDefault();
            e.stopPropagation();
            openNewsModal(card);
          });
        }
      });

      if (closeBtn) closeBtn.addEventListener("click", closeNewsModal);

      // Close modal when clicking outside content
      modal.addEventListener("click", e => {
        if (e.target === modal) closeNewsModal();
      });

      // ESC key closes modal
      document.addEventListener("keydown", e => {
        if (e.key === "Escape" && modal.classList.contains("show")) {
          closeNewsModal();
        }
      });
    })
    .catch(err => console.error("Error loading news:", err));
});
// open
document.getElementById("newsModal").classList.add("show");
document.body.style.overflow = "hidden";

// close
document.getElementById("newsModal").classList.remove("show");
document.body.style.overflow = "auto";
